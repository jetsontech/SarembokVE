# ==========================================
# Sarembok VE Fix + Full Bootstrap
# ==========================================

$ROOT = "C:\Sarembok_VE"
$PLUGIN = "$ROOT\Plugins\SarembokBridge\Source\SarembokBridge"
$PRIVATE = "$PLUGIN\Private"
$PUBLIC = "$PLUGIN\Public"

Write-Host ""
Write-Host "====================================="
Write-Host " Sarembok VE Fix + Bootstrap"
Write-Host "====================================="
Write-Host ""

# Fix generator paths
$BOOTSTRAP = "$ROOT\Tools\Builder\Bootstrap-Sarembok-Full.ps1"

Write-Host "[PATCH] Fixing Bootstrap generator"

(Get-Content $BOOTSTRAP) `
-replace '\$SOURCE\\SarembokRuntimeManager\.h', '$SOURCE\Public\SarembokRuntimeManager.h' `
-replace '\$SOURCE\\SarembokRuntimeManager\.cpp', '$SOURCE\Private\SarembokRuntimeManager.cpp' `
-replace '\$SOURCE\\SarembokBridgeModule\.h', '$SOURCE\Public\SarembokBridgeModule.h' `
-replace '\$SOURCE\\SarembokBridgeModule\.cpp', '$SOURCE\Private\SarembokBridgeModule.cpp' |
Set-Content $BOOTSTRAP -Encoding UTF8


# Remove duplicate root files
Write-Host "[CLEAN] Removing duplicate plugin files"

$DUPLICATES = @(
"$PLUGIN\SarembokRuntimeManager.h",
"$PLUGIN\SarembokRuntimeManager.cpp",
"$PLUGIN\SarembokBridgeModule.h",
"$PLUGIN\SarembokBridgeModule.cpp"
)

foreach($FILE in $DUPLICATES){
    if(Test-Path $FILE){
        Remove-Item $FILE -Force
        Write-Host "Removed $FILE"
    }
}


# Verify folders
Write-Host "[DIR] Ensuring Unreal folders"

New-Item "$PRIVATE" -ItemType Directory -Force | Out-Null
New-Item "$PUBLIC" -ItemType Directory -Force | Out-Null


# Clean Unreal cache
Write-Host "[CLEAN] Unreal Intermediate/Saved"

if(Test-Path "$ROOT\Intermediate"){
    Remove-Item "$ROOT\Intermediate" -Recurse -Force
}

if(Test-Path "$ROOT\Saved"){
    Remove-Item "$ROOT\Saved" -Recurse -Force
}


# Verify files
Write-Host ""
Write-Host "[VERIFY] Runtime Manager locations"

Get-ChildItem $PLUGIN -Recurse -Filter "SarembokRuntimeManager.*"


# Run actual bootstrap
Write-Host ""
Write-Host "[BUILD] Starting Sarembok Full Bootstrap"
Write-Host ""

Set-Location "$ROOT\Tools\Builder"

.\Bootstrap-Sarembok-Full.ps1


Write-Host ""
Write-Host "====================================="
Write-Host " Sarembok VE Bootstrap Finished"
Write-Host "====================================="